from time import sleep
from datetime import datetime


def get_current_data(sensor, weatherbit, openweathermap):
    current_weather_data_sensor = list()
    current_weather_data_wbit = list()
    current_weather_data_owm = list()
    while True:
        file_for_sensor = open(f"sensor_data.json", "w+")
        file_for_weatherbit = open(f"weatherbit_data.json", "w+")
        file_for_openweathermap = open(f"openweathermap_data.json", "w+")
        current_date = str(f"{str(datetime.now())}")
        humidity, temp = sensor.get_data()
        current_weather_data_sensor.append({current_date: {"temp": temp, "humidity": humidity}})
        file_for_sensor.writelines(str(current_weather_data_sensor))
        humidity, temp = weatherbit.get_current_data()
        current_weather_data_wbit.append({current_date: {"temp": temp, "humidity": humidity}})
        file_for_weatherbit.writelines(str(current_weather_data_wbit))
        humidity, temp = openweathermap.get_current_data()
        current_weather_data_owm.append({current_date: {"temp": temp, "humidity": humidity}})
        file_for_openweathermap.writelines(str(current_weather_data_owm))
        sleep(3600)

if __name__ == "__main__":
     print(get_current_data())


# get_sensor_current_data()